-- Boxing Server Script (Script in ServerScriptService)
local rs = game:GetService("ReplicatedStorage")
local players = game:GetService("Players")

local staminaData = {}
local blockState = {}
local lastBlockTime = {}

rs.PunchEvent.OnServerEvent:Connect(function(player)
	local char = player.Character
	if not char or not char:FindFirstChild("Humanoid") then return end

	if staminaData[player] and staminaData[player] < 10 then return end

	staminaData[player] -= 10
	rs.StaminaUpdate:FireClient(player, staminaData[player])

	local hit = nil
	for _, other in pairs(players:GetPlayers()) do
		if other ~= player and other.Character and other.Character:FindFirstChild("HumanoidRootPart") then
			local dist = (char.HumanoidRootPart.Position - other.Character.HumanoidRootPart.Position).Magnitude
			if dist <= 5 then
				hit = other
				break
			end
		end
	end

	if hit then
		local blocked = blockState[hit] or false
		if blocked then
			local blockTime = tick() - (lastBlockTime[hit] or 0)
			if blockTime < 0.3 then
				rs.CounterEvent:FireClient(hit)
				hit.Character.Humanoid:TakeDamage(5)
				player.Character.Humanoid:TakeDamage(15)
			end
		else
			hit.Character.Humanoid:TakeDamage(10)
		end
	end
end)

rs.BlockEvent.OnServerEvent:Connect(function(player, isBlocking)
	blockState[player] = isBlocking
	if isBlocking then
		lastBlockTime[player] = tick()
	end
end)

game:GetService("RunService").Heartbeat:Connect(function()
	for _, player in pairs(players:GetPlayers()) do
		if not staminaData[player] then
			staminaData[player] = 100
		else
			staminaData[player] = math.min(100, staminaData[player] + 0.2)
			rs.StaminaUpdate:FireClient(player, staminaData[player])
		end
	end
end)

players.PlayerRemoving:Connect(function(player)
	staminaData[player] = nil
	blockState[player] = nil
	lastBlockTime[player] = nil
end)
