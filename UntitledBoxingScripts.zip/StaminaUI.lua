-- LocalScript inside the StaminaBar Frame
local rs = game:GetService("ReplicatedStorage")

rs:WaitForChild("StaminaUpdate").OnClientEvent:Connect(function(stamina)
	script.Parent.Size = UDim2.new(stamina / 100, 0, 1, 0)
end)
